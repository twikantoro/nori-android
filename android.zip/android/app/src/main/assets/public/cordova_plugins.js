
  cordova.define('cordova/plugin_list', function(require, exports, module) {
    module.exports = [
      {
          "id": "phonegap-plugin-barcodescanner.BarcodeScanner",
          "file": "plugins/phonegap-plugin-barcodescanner/www/barcodescanner.js",
          "pluginId": "phonegap-plugin-barcodescanner",
        "clobbers": [
          "cordova.plugins.barcodeScanner"
        ]
        },
      {
          "id": "phonegap-plugin-push.PushNotification",
          "file": "plugins/phonegap-plugin-push/www/push.js",
          "pluginId": "phonegap-plugin-push",
        "clobbers": [
          "PushNotification"
        ]
        }
    ];
    module.exports.metadata =
    // TOP OF METADATA
    {
      "cordova-support-google-services": "1.4.0",
      "phonegap-plugin-barcodescanner": "8.1.0",
      "phonegap-plugin-multidex": "1.0.0",
      "phonegap-plugin-push": "2.3.0"
    };
    // BOTTOM OF METADATA
    });
    